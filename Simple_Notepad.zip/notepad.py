# -*- coding: utf-8 -*-
"""
Created on Sat Dec 31 20:53:31 2022

@author: bha
"""


from tkinter import*
from tkinter.messagebox import showinfo
from tkinter.filedialog import askopenfilename, asksaveasfilename 
import os


def newFile():
    global file
    root.title("Untitled - Notepad")
    file = None
    TextArea.delete(1.0,END)

def openFile():
    global file
    file = askopenfilename(defaultextension =".txt",
                            filetypes = [("All Files","*.*"),
                                      ("Text Document","*.txt")])
    if file == "":
        file = None
    else:
        root.title(os.path.basename(file) +"- Notepad")
        TextArea.delete(1.0,END)
        f=open(file,"r")
        TextArea.insert(1.0,f.read())
        f.close()
           

def saveFile():
    global file
    if file == None:
        file = asksaveasfilename(initialfile="Untitled.txt",
                               defaultextension = ".txt",
                               filetypes =[("All files","*.*"),
                                          ("Text Document","*.txt")])
        if file == "":
            file =None 
        else:
            #save as a new file
            f = open(file, "w")
            f.write(TextArea.get(1.0,END))
            f.close()
    else:
          #save the file
          f = open(file, "w")
          f.write(TextArea.get(1.0,END))
          f.close()       
          root.title(os.path.basename(file)+ "- Notepad")    
def quitApp():
    root.destroy()

def cut():
    TextArea.event_generate(("<<Cut>>"))
    

def copy():
    TextArea.event_generate(("<<Copy>>"))

def paste():
    TextArea.event_generate(("<<Paste>>"))

def about():
    showinfo("Notepad","Notpad by Bhaw")


if __name__ == '__main__' :
    
    root = Tk()
    root.title("Untitled - Notepad")

    p1 = PhotoImage(file = 'icon.png')
    #Setting icon of root window
    root.iconphoto(False, p1)
    root.geometry("644x765")
    
    #add text area
    TextArea = Text(root,font="lucida 13 bold")
    file = None
    TextArea.pack(expand=True, fill=BOTH)
    
    #lets create a menubar
    menubar = Menu(root)
    #file menu starts
    Filemenu = Menu(menubar,tearoff = 0)
    
    #To open new file
    Filemenu.add_command(label = "New", command=newFile)
    #To open already existing file
    Filemenu.add_command(label = "Open", command=openFile)
    #To save the current file
    Filemenu.add_command(label = "Save", command=saveFile)
    Filemenu.add_separator()
    Filemenu.add_command(label = "Exit", command=quitApp)
    menubar.add_cascade(label="File",menu = Filemenu)
    #file menu end 
    Editmenu = Menu(menubar,tearoff = 0)
    
    #To give a feature of cut,copy,paste
    Editmenu.add_command(label="Cut", command=cut)
    Editmenu.add_command(label="Copy", command=copy)
    Editmenu.add_command(label="Paste", command=paste)
    
    menubar.add_cascade(label="Edit",menu = Editmenu)
    #end edit manu
    
    #help menu start
    Helpmenu = Menu(menubar,tearoff=0)
     
    Helpmenu.add_command(label="About Notepad",command=about)
    menubar.add_cascade(label="Help",menu = Helpmenu)
    
    
    
    #Edit menu starts
    root.config(menu=menubar)
    
    #adding scrooling 
    Scroll = Scrollbar(TextArea)
    Scroll.pack(side=RIGHT,fill=Y)
    Scroll.config(command=TextArea.yview)
    TextArea.config(yscrollcommand=Scroll.set)
    root.mainloop()